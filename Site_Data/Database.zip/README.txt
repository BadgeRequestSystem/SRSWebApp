Use script.sql to build the database.

Import the standard data from Credentials.txt and Employees.txt

We used Microsoft SQL Studio to run our database.

-Devs